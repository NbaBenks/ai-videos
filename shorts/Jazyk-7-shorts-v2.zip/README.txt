JAZYK JAKO MOCNÝ NÁSTROJ — SHORTS, VERZE 2
Lenka Pawlasová | Adventisté Třinec – Folvark

S-HUDBOU: 7 videí s novým souvislým jemným klavírním podkresem.
BEZ-HUDBY: stejných 7 střihů s oddělenou řečí, bez nově přidaného podkresu.
TITULKY: samostatné české soubory SRT. Animované titulky jsou také přímo v obou variantách videa.

01 Slova pomáhají i zraňují — 35 s (původně 45 s)
02 Pomluvu už nechytíš — 38 s (původně 47 s)
03 Odpuštění a staré křivdy — 44 s (původně 50 s)
04 Respekt bez ponižování — 30 s (původně 37 s)
05 Pravda bez lásky — 31 s (původně 37 s)
06 Stejná slova, jiný tón — 37 s (původně 48 s)
07 Pošli dobré slovo dál — 41 s (původně 53 s)

CO SE ZMĚNILO
Řeč byla oddělena od původní hudby pomocí modelu UVR-MDX-NET-Voc_FT. Dlouhé mezery mezi slovy a větami byly zkráceny; rychlost řeči se nezměnila. Krátká 12ms prolnutí chrání před lupnutím ve střihu. Obě ukázky rozdílného tónu hlasu v klipu 06 zůstaly zachované.

Nový doprovod byl umístěn až na hotový sestřih. Není nastříhaný společně s jednotlivými větami, takže při střizích nepřeskakuje. Pod hlasem je ztišený. Hlasitost řeči je vyrovnaná přibližně na -16 LUFS.

Český text byl znovu porovnán s nezávislým přepisem a zkontrolován. Nové časování používá akustické zarovnání jednotlivých slov místo dřívějšího odhadu podle délky vět. Titulky mají 2–5 slov na blok. U přímé řeči v klipu 06 bylo doplněno označení citací.

Oddělení již smíchané řeči a hudby je modelová úprava; stopy mohou obsahovat slabé zbytky původního podkresu. Varianta BEZ-HUDBY neobsahuje nově přidanou hudbu.

FORMÁT
1080 × 1920, 9:16, 30 fps, H.264, stereo AAC, MP4.
Obraz zachovává původní dodanou fotografii kazatelky a vybrané detaily z původní prezentace.

HUDBA
Nový doprovod: původní jemná klavírní sekvence vytvořená pro tuto úpravu.
Syntéza: FluidSynth; soundfont TimGM6mb (Tim Brechbill a David Bolton, GPL-2.0).
Nejde o převzatou komerční hudební nahrávku. Přiložený skript music.py zaznamenává skladbu a způsob vytvoření doprovodu.

ZDROJE
Video: https://github.com/NbaBenks/ai-videos/releases/download/videa/0911.1.3.mp4
Fotografie: https://github.com/NbaBenks/ai-videos/releases/download/videa/maxresdefault.jpg

DOKUMENTACE
revision-report.json obsahuje přehled časových úspor a zdrojových intervalů střihu.
final-validation.json obsahuje výsledky kontrol přehratelnosti, obrazu, délky, hlasitosti, špiček a časování titulků.
