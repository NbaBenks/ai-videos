# Když chybí král — šest vertikálních klipů

Rostislav Hudziec · 28. 2. 2026 · Adventisté Třinec – Folvark

MP4: 1080 × 1920, 9:16, 30 sn./s, H.264 + AAC. České titulky jsou součástí obrazu; přiložené SRT umožňují další úpravy.

## Přehled

| Soubor | Délka | Úryvky v původním videu |
|---|---:|---|
| 01-kazdy-ma-svou-pravdu.mp4 | 36.35 s | 09:42.10–10:04.50, 10:31.00–10:49.05 |
| 02-buh-podle-nasich-predstav.mp4 | 46.68 s | 12:52.70–13:41.55 |
| 03-pozehnani-bez-poslusnosti.mp4 | 37.03 s | 26:17.08–26:55.40 |
| 04-je-kristus-tvym-kralem.mp4 | 40.44 s | 28:16.80–28:40.20, 29:01.30–29:23.70 |
| 05-kdo-drzi-volant.mp4 | 44.95 s | 30:01.22–30:20.00, 30:51.95–31:26.15 |
| 06-pravy-kral-prinasi-pokoj.mp4 | 44.24 s | 28:40.80–29:00.65, 31:28.28–32:01.35 |

## Zpracování

- Původní hlas a pořadí zachovaných vět. Bez dopisování mluvených vět a bez syntézy hlasu.
- Zkrácené delší pauzy, jemné ošetření střihů, normalizace řeči a tichý instrumentální podkres s automatickým ztišením během řeči.
- Původní soubor obsahuje statickou titulní grafiku. Použit je její portrét s jemným digitálním pohybem a vlastní symbolické ilustrace; zdroj neobsahuje záběry kazatele při řeči.
- Hudební podkresy jsou vlastní synteticky vytvořené instrumentální plochy. Symbolické ilustrace jsou vlastní kresby. Externí hudební nahrávky ani historické biblické rekonstrukce nebyly použity.
- Úvodní text trvá 1,35 s, závěrečný titul 1,25 s.

## Kontrola a titulky

Titulky vznikly automatickým rozpoznáním češtiny, porovnáním přepisů a jazykovou úpravou. Časování krátkých bloků je vypočtené z časů vět a energie řeči; nejedná se o ověřené časování každého jednotlivého slova. Před zveřejněním je vhodná závěrečná sluchová kontrola přesného znění a synchronizace.

Technické výsledky exportů jsou v souboru `validation.json`. Zdrojové intervaly, titulky a nastavení každého klipu jsou v `edit-plan.json`.

Zdrojové video: https://github.com/NbaBenks/ai-videos/releases/tag/videa
SHA-256 zdroje: `bab023f5ff854afc45211417fcb6f03737b2fb08bd6336abb3288fee0405ea76`

Ověřeno: všech šest MP4 prošlo úplným dekódováním bez chyb; rozlišení 1080 × 1920. Integrovaná hlasitost výsledků je −16,90 až −16,34 LUFS; skutečné špičky −2,01 až −1,84 dBTP. Náhledy úvodu, řeči, symbolického prostřihu a závěru jsou v review-sheet-1.jpg a review-sheet-2.jpg.
