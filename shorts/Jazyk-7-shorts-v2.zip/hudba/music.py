from pathlib import Path
import numpy as np,soundfile as sf,fluidsynth,json
V=Path('/workspace/sermon-jazyk/revision-v2');SR=44100
s=fluidsynth.Synth(samplerate=float(SR),gain=.35)
bank=s.sfload('/usr/share/sounds/sf2/TimGM6mb.sf2');s.program_select(0,bank,0,0)
s.cc(0,91,45);s.cc(0,93,12)
# Original sparse piano accompaniment. One continuous performance, never cut with speech.
chords=[[48,55,60,64,71],[45,52,57,60,67],[41,48,53,57,64],[43,50,55,62,69]]
beat=60/68;events=[];rng=np.random.default_rng(842)
for bar in range(20):
 notes=chords[bar%4];base=bar*4*beat
 for k,ix in enumerate([0,2,3,4]):
  when=base+k*beat+(0 if k==0 else float(rng.uniform(-.018,.018)));pitch=notes[ix]
  vel=[36,29,28,25][k]+int(rng.integers(-2,3));length=beat*(3.7 if k==0 else 2.9)
  events.extend([(when,True,pitch,vel),(when+length,False,pitch,0)])
events.sort(key=lambda e:e[0]);chunks=[];pos=0
for t,on,n,v in events:
 target=round(t*SR)
 if target>pos:chunks.append(s.get_samples(target-pos));pos=target
 if on:s.noteon(0,n,v)
 else:s.noteoff(0,n)
chunks.append(s.get_samples(3*SR));y=np.concatenate(chunks).reshape(-1,2).astype('float32')/32768
s.delete();y*=np.linspace(0,1,min(SR,len(y)))[:,None] if len(y)<=SR else 1
sf.write(V/'audio/original-piano-bed.wav',y,SR,subtype='FLOAT')
(V/'audio/music-credits.json').write_text(json.dumps({'composition':'Original sparse piano accompaniment, created for this edit','synthesis':'FluidSynth, acoustic grand piano','soundfont':'TimGM6mb.sf2','soundfont_license':'TimGM6mb soundfont: GPL-2.0; rendered accompaniment is an original performance','tempo_bpm':68,'continuous_music_not_cut_with_speech':True},indent=2))
print('Created',len(y)/SR,'seconds continuous piano',flush=True)
