LENKA PAWLASOVÁ — 7 SHORTS SE SJEDNOCENÝMI NÁZVY A OBRAZY
Adventisté Třinec – Folvark | Jazyk jako mocný nástroj

Složka s-hudbou: sedm Shortů s Leanin Slowed.
Složka bez-hudby: stejných sedm videí bez nově přidané hudby.
Složka titulky: české samostatné SRT.

01 Slova pomáhají i zraňují — 35 s
02 Pomluvu už nechytíš — 38 s
03 Odpuštění a staré křivdy — 44 s
04 Respekt bez ponižování — 30 s
05 Pravda bez lásky — 31 s
06 Stejná slova, jiný tón — 37 s
07 Pošli dobré slovo dál — 41 s

Každé video má tři různé ilustrační záběry odpovídající konkrétním větám a ději. Nůž, péče o druhého, bolest ze slov, šíření pomluv, rozhovor mezi čtyřma očima, respektující trenér, Bible, láskyplný nebo podrážděný tón, modlitba a odeslání povzbudivé zprávy. Anonymní generovaní lidé nepředstavují skutečné účastníky událostí. Hlavní fotografie kazatelky je původní dodaná.

Úvodní názvy mají samostatnou krémovou zaoblenou kartu, tmavé tučné patkové Noto Serif a drobný barevný tematický nadpis. Mluvené titulky jsou oddělené, bílé bezpatkové Noto Sans, 2–5 slov v jednom bloku.

Zvukové stopy jsou z posledních schválených mixů převzaté beze změny: Leanin Slowed pod řečí nebo varianta bez nově přidané hudby. Střih, časování a text mluvených titulků jsou zachované. Modelové oddělení může ponechat slabé reziduum původního podkresu. Obě demonstrace rozdílného tónu hlasu v klipu 06 zůstaly zachované.

MP4: 1080 × 1920, 30 fps, H.264, stereo AAC. Všech 14 souborů prošlo plným dekódováním, kontrolou obrazu, délky, totožnosti původní zvukové stopy, titulků a odlišné typografie názvu.

Samostatný již upravený celý příběh o peří (1:22):
https://raw.githubusercontent.com/NbaBenks/ai-videos/peri-obrazky-titulek-20261018/shorts/Pribeh-o-peri-nove-obrazky.zip
