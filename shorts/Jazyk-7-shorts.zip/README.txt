JAZYK JAKO MOCNÝ NÁSTROJ — 7 SHORTS
Lenka Pawlasová | Adventisté Třinec – Folvark

01 Slova pomáhají i zraňují — 45 s
02 Pomluvu už nechytíš — 47 s
03 Odpuštění a staré křivdy — 50 s
04 Respekt bez ponižování — 37 s
05 Pravda bez lásky — 37 s
06 Stejná slova, jiný tón — 48 s
07 Pošli dobré slovo dál — 53 s

MP4: 1080 × 1920, 9:16, 30 fps, H.264, stereo AAC.
České animované titulky jsou přímo v obrazu. Samostatné soubory SRT jsou ve složce titulky.

Obraz používá výřez původní dodané fotografie kazatelky, jemné přiblížení a vhodné detaily z obrazového doprovodu původního kázání. Fotografie není simulací mluvícího videa. Nebyla vytvořena ani upravena tvář.

Zvuk pochází výhradně z původního kázání včetně jeho hudby. Nebyla přidána nová hudba. Úpravy zvuku: střih, krátké přechody a konstantní nastavení hlasitosti. Žádné oddělování hudby, změny rychlosti řeči ani dynamická komprese.

Výběr a titulky vycházejí z přepisu kázání. Text byl zkontrolován podle dostupných přepisů, časování je automatické. Před zveřejněním doporučujeme poslední poslechovou kontrolu českých slov a jejich synchronizace. Technické kontroly zahrnují úplné dekódování MP4, formát, délku, špičky zvuku a strukturu titulků; nenahrazují lidskou poslechovou korekturu.

Zdroj videa:
https://github.com/NbaBenks/ai-videos/releases/download/videa/0911.1.3.mp4
Zdroj fotografie:
https://github.com/NbaBenks/ai-videos/releases/download/videa/maxresdefault.jpg

edit-plan.json obsahuje přesná místa výběru v původním kázání.
final-validation.json obsahuje výsledky technických kontrol.
