PŘÍBĚH O PEŘÍ — UPRAVENÉ OBRAZY A NÁZEV
Lenka Pawlasová | Adventisté Třinec – Folvark

Délka 1:22, 1080 × 1920, 30 fps. Celý příběh, střih řeči, české titulky a zvuk jsou zachované.

Pět různých realistických generovaných ilustrací odpovídá pěti konkrétním větám: svěření problému kazateli, sbírání peří do košíčku, vysypání peří z výšky, peří zachycené na stromě, soukromý rozhovor mezi čtyřma očima. Každý obrázek se použije právě jednou. Ilustrační anonymní lidé nepředstavují skutečnou kazatelku ani historické účastníky příběhu.

Úvodní název má vlastní světlou zaoblenou kartu, tmavé tučné patkové písmo Noto Serif a drobný barevný nadpis. Titulky řeči zůstávají bílé bezpatkové Noto Sans, odděleně pod kartou.

Hlavní MP4 obsahuje Leanin Slowed. Druhé MP4 je bez nově přidané hudby. Obě zvukové stopy jsou z předchozí schválené verze převzaté bitově beze změny.

Přiložené SRT a název s popiskem platí pro obě varianty.
