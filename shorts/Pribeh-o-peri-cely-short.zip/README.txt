CELÝ PŘÍBĚH O PEŘÍ A POMLUVÁCH
Lenka Pawlasová | Adventisté Třinec – Folvark

Délka přibližně 1 minuta 22 sekund, vertikální 9:16, 1080 × 1920, 30 fps, H.264 a stereo AAC.

Obsahuje celý příběh o ženě, kazateli a peří: svěření problému, úkol, vysypání peří, nemožnost jeho posbírání, vysvětlení souvislosti s pomluvami a závěrečnou radu z Matoušova evangelia. Původní pořadí i význam vět jsou zachované. Vynechán byl úvod „Chtěla bych vám vyprávět…“ a zkráceny pouze dlouhé pauzy; řeč nebyla zrychlována. Zdrojový úryvek 8:20.70–10:01.90 původního kázání.

Hlavní MP4 obsahuje dodanou písničku Leanin Slowed, souvisle pod řečí. Druhé MP4 obsahuje oddělenou řeč bez nově přidané hudby. Modelové oddělení může zanechat slabé stopy původního podkresu.

České animované titulky mají 2–5 slov v jednom bloku a jsou časované akustickým zarovnáním jednotlivých slov. Text byl porovnán se dvěma nezávislými přepisy. Samostatné SRT a připravený název s popiskem jsou přiložené.

Obraz používá původní dodanou fotografii kazatelky a doprovodný generovaný obraz peří nad městem.

Video: https://github.com/NbaBenks/ai-videos/releases/download/videa/0911.1.3.mp4
Fotografie: https://github.com/NbaBenks/ai-videos/releases/download/videa/maxresdefault.jpg
Hudba: https://github.com/NbaBenks/ai-videos/releases/download/videa/Leanin.Slowed.mp3
