PRVNÍ SHORT — SLOVA POMÁHAJÍ I ZRAŇUJÍ

Aktualizace obrázku nože: nový realistický generovaný detail celého kuchyňského nože na prkénku vedle nakrájeného chleba, bez textu. Záběr je u úvodu a vět o přípravě jídla (1,7–9,7 s).

Složka s-hudbou: původní souvislý podkres z verze 2.
Složka bez-hudby: varianta bez přidaného podkresu z verze 2.
Obě původní zvukové stopy jsou převzaté bitově beze změny. Střih řeči a titulky zůstávají stejné. Video má délku přibližně 35 sekund, 1080 × 1920, 30 fps.
Ostatních šest shortů najdete v předchozím balíčku verze 2.
