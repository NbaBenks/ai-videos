JAZYK JAKO MOCNÝ NÁSTROJ — 7 SHORTS S HUDBOU LEANIN
Lenka Pawlasová | Adventisté Třinec – Folvark

Všech sedm reelů používá dodaný soubor Leanin.Slowed.mp3 jako nový souvislý podkres. Hudba začíná od začátku souboru, má jemný náběh a zakončení, pod řečí se automaticky ztišuje. Nebyla stříhána společně s větami. Předchozí klavírní doprovod nebyl použit.

Zachován kratší střih řeči, české animované titulky a jejich časování. První short má nový obrázek celého nože vedle chleba. Obrazové stopy byly převzaty beze změny a bez dalšího překódování z posledních verzí jednotlivých videí.

MP4: 1080 × 1920, 30 fps, H.264, stereo AAC.
Ve složce titulky jsou samostatné SRT.

Hudba dodaná uživatelem:
https://github.com/NbaBenks/ai-videos/releases/download/videa/Leanin.Slowed.mp3

Kontroly: přehratelnost celého souboru, totožnost obrazové stopy s předchozí verzí, soulad řeči s novým mixem, formát, délka, hlasitost a špičky.
